package main

import (
	"context"
	"encoding/hex"
	"net/http"
	"net/http/httptest"
	"regexp"
	"strconv"
	"strings"
	"testing"
	"time"
)

// Values from the board's own code (wd_util.h wd_hash, wd_auth.h), compiled on a PC.
func TestMatchesBoard(t *testing.T) {
	if h := planHash(3, "1.50/6.10/11.10/149.10"); h != 24358 {
		t.Fatalf("plan hash %d, board says 24358", h)
	}
	key := make([]byte, 16)
	for i := range key {
		key[i] = byte(i*7 + 1)
	}
	if id := ownerID(key); id != 5696 {
		t.Fatalf("owner id %d, board says 5696", id)
	}
	tag := helloTag(key, []byte{1, 2, 3, 4, 5, 6, 7, 8}, [6]byte{0xB8, 0x27, 0xEB, 0x12, 0x34, 0x56})
	if hex.EncodeToString(tag) != "5da02257ddd8744b" {
		t.Fatalf("hello tag %x, board says 5da02257ddd8744b", tag)
	}
}

// phone is a tiny stand-in for the app's side of the link.
type phone struct {
	t       *testing.T
	n       *Node
	buf     string
	seen    []string
	seal    *sealer // the link is sealed (after RSP:hello:OK:e=1)
	pending *sealer // keys for the seal, once the node agrees
}

func (p *phone) write(lines ...string) {
	for _, l := range lines {
		if p.seal != nil {
			p.n.Write([]byte(p.seal.close(l)))
		} else {
			p.n.Write([]byte(l + "\n"))
		}
	}
}

// prove answers the node's owner challenge the way the app does, which seals the link.
func (p *phone) prove(challenge string, key []byte) {
	nonce, _ := hex.DecodeString(challenge[strings.Index(challenge, "c=")+2:])
	tag := hex.EncodeToString(helloTag(key, nonce, p.n.mac))
	p.write("CMD:hello:v=6,a=" + tag + ",e=1")
	z := newSealer(key, nonce, p.n.mac)
	z.me, z.other = 'P', 'N'
	p.pending = z
}

// drain runs the node for a moment and returns the complete lines it sent, read 20 bytes at a time
// (the smallest MTU) to prove lines survive being cut across notifications.
func (p *phone) drain() []string {
	var got []string
	for i := 0; i < 400; i++ {
		p.n.Tick(time.Now())
		for {
			b := p.n.TakeOut(20)
			if b == nil {
				break
			}
			p.buf += string(b)
		}
	}
	for {
		i := strings.IndexByte(p.buf, '\n')
		if i < 0 {
			break
		}
		l := p.buf[:i]
		p.buf = p.buf[i+1:]
		if p.seal != nil {
			t, ok := p.seal.open(l)
			if !ok {
				p.t.Fatalf("unsealed or bad line on a sealed link: %q", l)
			}
			l = t
		}
		if l == "RSP:hello:OK:e=1" && p.pending != nil {
			p.seal, p.pending = p.pending, nil
		}
		got = append(got, l)
	}
	p.seen = append(p.seen, got...)
	return got
}

func find(lines []string, prefix string) []string {
	var out []string
	for _, l := range lines {
		if strings.HasPrefix(l, prefix) {
			out = append(out, l)
		}
	}
	return out
}

// The app's own parse of an AP line (Protocol.kt parseAp), to be sure it takes ours.
var apRe = regexp.MustCompile(`^DATA:AP:([^,]*),([0-9A-F]{2}(:[0-9A-F]{2}){5}),(\d+),(-?\d+),\[([A-Z0-9_]+)\],q=(\d+),t=(\d+),s=(\d+)$`)
var btRe = regexp.MustCompile(`^DATA:BT:([^,]*),([0-9A-F]{2}(:[0-9A-F]{2}){5}),(-?\d+),BLE,q=(\d+),t=(\d+),s=(\d+)$`)

func TestSessionFlow(t *testing.T) {
	dir := t.TempDir()
	n, err := newNode(dir, 1000, time.Minute)
	if err != nil {
		t.Fatal(err)
	}
	n.SetMAC([6]byte{0xB8, 0x27, 0xEB, 0x12, 0x34, 0x56})
	p := &phone{t: t, n: n}

	// not scanning: Kismet's sightings are ignored
	if n.Add(Rec{Kind: recWifi, MAC: "AA:BB:CC:DD:EE:01", Name: "x", Ch: 6, RSSI: -60, Sec: "OPEN", T: time.Now().Unix()}) {
		t.Fatal("queued a sighting while not scanning")
	}

	n.Connected()
	phoneNow := time.Now().Add(100 * time.Second).UTC() // the phone's clock is 100 s ahead of ours
	p.write("TIME:SYNC:"+phoneNow.Format("2006-01-02T15:04:05Z"), "CMD:hello:v=6")
	out := p.drain()
	if len(find(out, "RSP:hello:OK")) != 1 {
		t.Fatalf("no hello OK: %q", out)
	}
	beats := find(out, "DATA:BEAT:")
	if len(beats) == 0 || !strings.Contains(beats[0], "f=184") { // 5G|flash|synced|kismet, no owner, not running
		t.Fatalf("beat: %q", beats)
	}

	// the app makes it its own, then proves the key (which seals the link), numbers it and starts a scan
	key := "000102030405060708090a0b0c0d0e0f"
	k, _ := hex.DecodeString(key)
	p.write("CMD:own:k="+key, "CMD:hello:v=6")
	out = p.drain()
	ch := find(out, "RSP:hello:ERROR:owned,o=")
	if len(find(out, "RSP:own:OK")) != 1 || len(ch) != 1 {
		t.Fatalf("own: %q", out)
	}
	// an app that doesn't seal is turned away even with the right key
	nonce, _ := hex.DecodeString(ch[0][strings.Index(ch[0], "c=")+2:])
	p.write("CMD:hello:v=6,a=" + hex.EncodeToString(helloTag(k, nonce, n.mac)))
	out = p.drain()
	if len(find(out, "RSP:hello:ERROR:update")) != 1 || n.seal != nil {
		t.Fatalf("unsealed hello: %q", out)
	}
	p.write("CMD:hello:v=6")
	ch = find(p.drain(), "RSP:hello:ERROR:owned,o=")
	p.prove(ch[0], k)
	out = p.drain()
	p.write("CMD:slot:n=4", "CMD:plan:f=3,ch=1.50/6.10", "CMD:run:m=3,s=7")
	out = append(out, p.drain()...)
	if p.seal == nil {
		t.Fatalf("link not sealed: %q", out)
	}
	for _, want := range []string{"RSP:hello:OK:e=1", "RSP:slot:OK", "RSP:plan:OK", "RSP:run:OK"} {
		if len(find(out, want)) != 1 {
			t.Fatalf("missing %s in %q", want, out)
		}
	}
	b := find(out, "DATA:BEAT:")
	last := b[len(b)-1]
	if !strings.Contains(last, "n=4") || !strings.Contains(last, "m=3") || !strings.Contains(last, "s=7") ||
		!strings.Contains(last, ",h="+itoa(planHash(3, "1.50/6.10"))+",") || !strings.Contains(last, "f=249") {
		t.Fatalf("beat after setup: %s", last)
	}

	now := time.Now().Unix()
	n.Add(Rec{Kind: recWifi, MAC: "AA:BB:CC:DD:EE:01", Name: "Cafe, free", Ch: 6, RSSI: -60, Sec: "WPA2_PSK", T: now})
	n.Add(Rec{Kind: recBLE, MAC: "11:22:33:44:55:66", Name: "Tile", RSSI: -70, T: now})
	if n.Add(Rec{Kind: recWifi, MAC: "AA:BB:CC:DD:EE:01", Name: "Cafe, free", Ch: 6, RSSI: -55, Sec: "WPA2_PSK", T: now}) {
		t.Fatal("the same device went in twice")
	}
	out = p.drain()
	aps, bts := find(out, "DATA:AP:"), find(out, "DATA:BT:")
	if len(aps) != 1 || len(bts) != 1 {
		t.Fatalf("sightings: %q", out)
	}
	m := apRe.FindStringSubmatch(aps[0])
	if m == nil || m[1] != "Cafe_ free" || m[6] != "WPA2_PSK" || m[9] != "7" {
		t.Fatalf("AP line: %s", aps[0])
	}
	if ts := atoi(m[8]); ts < now+95 || ts > now+105 {
		t.Fatalf("time not moved to the phone's clock: %s", aps[0])
	}
	if btRe.FindStringSubmatch(bts[0]) == nil {
		t.Fatalf("BT line: %s", bts[0])
	}

	// the phone acks the first: it is gone from the queue
	q0 := atoi(m[7])
	p.write("CMD:ack:n=" + itoa(int(q0)+1))
	p.drain()
	if n.q.Len() != 1 {
		t.Fatalf("queue %d after ack, want 1", n.q.Len())
	}

	// the phone leaves; Kismet keeps reporting; the node holds it (and survives a restart)
	n.Disconnected()
	n.Add(Rec{Kind: recWifi, MAC: "AA:BB:CC:DD:EE:02", Name: "Home", Ch: 36, RSSI: -80, Sec: "OPEN", T: now})
	n.Close()

	n2, err := newNode(dir, 1000, time.Minute)
	if err != nil {
		t.Fatal(err)
	}
	n2.SetMAC([6]byte{0xB8, 0x27, 0xEB, 0x12, 0x34, 0x56})
	if n2.q.Len() != 2 || n2.st.Slot != 4 || n2.st.Run != 3 || n2.key == nil {
		t.Fatalf("after restart: queue %d slot %d run %d owned %v", n2.q.Len(), n2.st.Slot, n2.st.Run, n2.key != nil)
	}
	p2 := &phone{t: t, n: n2}
	n2.Connected()
	// owned now: a hello without the key gets a challenge, and nothing else is taken
	p2.write("CMD:hello:v=6", "CMD:run:m=0,s=7")
	out = p2.drain()
	ch = find(out, "RSP:hello:ERROR:owned,o=")
	if len(ch) != 1 || len(find(out, "RSP:run:ERROR:owned")) != 1 || len(find(out, "DATA:")) != 0 {
		t.Fatalf("locked node answered: %q", out)
	}
	p2.prove(ch[0], k)
	p2.drain()
	// a line written in the clear on a sealed link is ignored
	p2.n.Write([]byte("CMD:run:m=0,s=7\n"))
	p2.write("TIME:SYNC:" + time.Now().UTC().Format("2006-01-02T15:04:05Z"))
	out = p2.drain()
	if n2.st.Run != 3 {
		t.Fatal("took a command in the clear on a sealed link")
	}
	if len(find(p2.seen, "RSP:hello:OK:e=1")) != 1 || len(find(out, "DATA:BT:")) != 1 || len(find(out, "DATA:AP:Home,")) != 1 {
		t.Fatalf("after proving the key: %q", out)
	}
	// seqs never go backwards after a restart
	bt := btRe.FindStringSubmatch(find(out, "DATA:BT:")[0])
	ap := apRe.FindStringSubmatch(find(out, "DATA:AP:Home,")[0])
	if atoi(ap[7]) <= atoi(bt[5]) {
		t.Fatalf("seqs out of order: %s / %s", bt[0], ap[0])
	}
	// stop: new sightings are ignored
	p2.write("CMD:run:m=0,s=7")
	p2.drain()
	if n2.Add(Rec{Kind: recBLE, MAC: "11:22:33:44:55:77", RSSI: -70, T: now}) {
		t.Fatal("queued while stopped")
	}
	// Wi-Fi only scan: BLE ignored
	p2.write("CMD:run:m=1,s=8")
	p2.drain()
	if n2.Add(Rec{Kind: recBLE, MAC: "11:22:33:44:55:77", RSSI: -70, T: now}) {
		t.Fatal("queued BLE in a Wi-Fi only scan")
	}
	// a new scan sends a device again
	if !n2.Add(Rec{Kind: recWifi, MAC: "AA:BB:CC:DD:EE:01", Name: "Cafe, free", Ch: 6, RSSI: -60, Sec: "WPA2_PSK", T: now}) {
		t.Fatal("a new scan didn't take a device seen in the last one")
	}
	n2.Close()
}

func TestKismetFeed(t *testing.T) {
	var gotForm string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		r.ParseForm()
		gotForm = r.URL.Path + " " + r.Form.Get("json")
		if c, err := r.Cookie("KISMET"); err != nil || c.Value != "k3y" {
			w.WriteHeader(401)
			return
		}
		w.Write([]byte(`[
 {"mac":"AA:BB:CC:DD:EE:01","phy":"IEEE802.11","type":"Wi-Fi AP","name":"Cafe","channel":"6","freq":2437000,"rssi":-61,"crypt":"WPA2-PSK","last":1760000000},
 {"mac":"AA:BB:CC:DD:EE:02","phy":"IEEE802.11","type":"Wi-Fi AP","name":"AA:BB:CC:DD:EE:02","channel":"36","freq":5180000,"rssi":-75,"crypt":"WPA2 WPA3-SAE","last":1760000001},
 {"mac":"AA:BB:CC:DD:EE:03","phy":"IEEE802.11","type":"Wi-Fi Client","name":"phone","channel":"6","freq":2437000,"rssi":-50,"crypt":"","last":1760000001},
 {"mac":"AA:BB:CC:DD:EE:04","phy":"IEEE802.11","type":"Wi-Fi AP","name":"Six","channel":"5","freq":5975000,"rssi":-50,"crypt":"Open","last":1760000001},
 {"mac":"11:22:33:44:55:66","phy":"BTLE","type":"BTLE","name":"Tile","channel":"","freq":0,"rssi":-70,"crypt":"","last":1760000002},
 {"mac":"00:00:00:00:00:01","phy":"RTL433","type":"Sensor","name":"Thermo","channel":"","freq":433920,"rssi":0,"crypt":"","last":1760000002}
]`))
	}))
	defer srv.Close()
	k := &KismetFeed{base: srv.URL, apikey: "k3y", poll: time.Second, client: &http.Client{Timeout: time.Second}}
	devs, err := k.fetch(context.Background())
	if err != nil {
		t.Fatal(err)
	}
	if !strings.HasPrefix(gotForm, "/devices/last-time/-30/devices.json ") || !strings.Contains(gotForm, `"kismet.device.base.signal/kismet.common.signal.last_signal","rssi"`) {
		t.Fatalf("request: %s", gotForm)
	}
	var recs []Rec
	for _, d := range devs {
		if r, ok := d.rec(); ok {
			recs = append(recs, r)
		}
	}
	if len(recs) != 3 {
		t.Fatalf("recs %+v", recs)
	}
	if recs[0].Ch != 6 || recs[0].Sec != "WPA2_PSK" || recs[0].Name != "Cafe" || recs[0].T != 1760000000 {
		t.Fatalf("AP: %+v", recs[0])
	}
	if recs[1].Ch != 36 || recs[1].Sec != "WPA2_WPA3_PSK" || recs[1].Name != "" {
		t.Fatalf("hidden 5 GHz AP: %+v", recs[1])
	}
	if recs[2].Kind != recBLE || recs[2].Name != "Tile" {
		t.Fatalf("BLE: %+v", recs[2])
	}
	if k.since != 1760000002 {
		t.Fatalf("since %d", k.since)
	}
	k.fetch(context.Background())
	if !strings.HasPrefix(gotForm, "/devices/last-time/1760000000/") {
		t.Fatalf("second request: %s", gotForm)
	}
}

func TestPipe(t *testing.T) {
	cols := map[string]int{}
	hdr := splitCSV("MAC,SSID,AuthMode,FirstSeen,Channel,Frequency,RSSI,CurrentLatitude,CurrentLongitude,AltitudeMeters,AccuracyMeters,RCOIs,MfgrId,Type")
	for i, c := range hdr {
		cols[strings.ToUpper(c)] = i
	}
	r, ok := parseWigleRow(splitCSV(`aa:bb:cc:dd:ee:01,"Bob's, wifi",[WPA-PSK-TKIP][WPA2-PSK-CCMP][ESS],2026-10-13 01:02:03,11,2462,-67,0,0,0,0,,,WIFI`), cols)
	if !ok || r.Name != "Bob's, wifi" || r.Ch != 11 || r.Sec != "WPA_WPA2_PSK" || r.MAC != "AA:BB:CC:DD:EE:01" {
		t.Fatalf("wigle row: %+v %v", r, ok)
	}
	r, ok = parseWigleRow(splitCSV(`11:22:33:44:55:66,Tile,Misc [LE],2026-10-13 01:02:03,0,,-80,0,0,0,0,,,BLE`), cols)
	if !ok || r.Kind != recBLE {
		t.Fatalf("wigle BLE row: %+v %v", r, ok)
	}
	r, ok = parsePipeJSON(`{"type":"wifi","mac":"aa:bb:cc:dd:ee:09","ssid":"Lib","channel":149,"rssi":-70,"security":"[ESS]"}`)
	if !ok || r.Ch != 149 || r.Sec != "OPEN" {
		t.Fatalf("json: %+v %v", r, ok)
	}
	for in, want := range map[string]string{"Open": "OPEN", "WEP": "WEP", "WPA-PSK": "WPA_PSK", "WPA2-EAP": "WPA2_ENTERPRISE",
		"[WPA2-PSK-CCMP][ESS]": "WPA2_PSK", "[WPA3-SAE-CCMP][ESS]": "WPA3_PSK", "OWE": "OWE", "": "OPEN"} {
		if got := secToken(in); got != want {
			t.Errorf("secToken(%q) = %s, want %s", in, got, want)
		}
	}
}

func itoa(i int) string { return strconv.Itoa(i) }

func atoi(s string) int64 { v, _ := strconv.ParseInt(s, 10, 64); return v }
