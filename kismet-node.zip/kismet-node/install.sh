#!/bin/sh
# Installs swarm-kismet-node as a service that starts at boot. Run with sudo from this folder.
set -e
cd "$(dirname "$0")"
if [ "$(id -u)" != 0 ]; then echo "Run it with sudo: sudo sh install.sh"; exit 1; fi
case "$(uname -m)" in
  x86_64|amd64) bin=bin/swarm-kismet-node-x86_64 ;;
  aarch64|arm64) bin=bin/swarm-kismet-node-arm64 ;;
  armv6l|armv7l|armhf) bin=bin/swarm-kismet-node-armhf ;;
  *) echo "No program for $(uname -m) in this package"; exit 1 ;;
esac
systemctl stop swarm-kismet-node 2>/dev/null || true
install -m 755 "$bin" /usr/local/bin/swarm-kismet-node
if [ ! -f /etc/default/swarm-kismet-node ]; then
  cat > /etc/default/swarm-kismet-node <<'CONF'
# Options for swarm-kismet-node (see: swarm-kismet-node -help).
# Put your Kismet login here: the name and password you set the first time you opened Kismet's
# web page, or an API key from Kismet's settings (then use -apikey YOURKEY instead).
SWARM_KISMET_ARGS="-user kismet -pass changeme"
CONF
  echo "Wrote /etc/default/swarm-kismet-node: put your Kismet login in it, then: sudo systemctl restart swarm-kismet-node"
fi
install -m 644 swarm-kismet-node.service /etc/systemd/system/swarm-kismet-node.service
systemctl daemon-reload
systemctl enable --now swarm-kismet-node
echo "Installed $(/usr/local/bin/swarm-kismet-node -version). Watch it with: journalctl -u swarm-kismet-node -f"
