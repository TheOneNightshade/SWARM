package main

import (
	"strings"
	"time"
)

// Filter keeps the Bluetooth link from carrying what the phone doesn't need. The app logs each device once
// per scan, so a device is sent when it is first seen in the scan, when its name changes, and again after
// [resend] if Kismet still sees it (in case the phone had no GPS fix the first time). Everything else
// Kismet reports is dropped here.
type Filter struct {
	resend time.Duration
	seen   map[string]seenDev
}

type seenDev struct {
	sent time.Time
	name string
}

func newFilter(resend time.Duration) *Filter {
	return &Filter{resend: resend, seen: make(map[string]seenDev)}
}

func (f *Filter) Reset() { f.seen = make(map[string]seenDev) }

func (f *Filter) Pass(r Rec, now time.Time) bool {
	k := string(rune('0'+r.Kind)) + strings.ToUpper(r.MAC)
	d, ok := f.seen[k]
	if ok && d.name == r.Name && now.Sub(d.sent) < f.resend {
		return false
	}
	f.seen[k] = seenDev{sent: now, name: r.Name}
	if len(f.seen) > 500_000 { // a very long scan: forget the oldest half rather than grow forever
		cut := now.Add(-f.resend / 2)
		for key, v := range f.seen {
			if v.sent.Before(cut) {
				delete(f.seen, key)
			}
		}
	}
	return true
}
