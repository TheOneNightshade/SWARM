//go:build linux

package main

import (
	"context"
	"fmt"
	"strings"
	"sync"
	"time"

	"github.com/godbus/dbus/v5"
)

// The Swarm node service, exactly as a board serves it (protocol.h, "GATT"), so the app links to this
// computer the way it links to a board. Served through BlueZ (bluetoothd) over D-Bus: no C library, so the
// program is one static file.
const (
	svcUUID    = "4fafc201-1fb5-459e-8fcc-c5c9c331914b"
	cmdUUID    = "beb5483e-36e1-4688-b7f5-ea07361b26a8"
	rspUUID    = "beb5483e-36e1-4688-b7f5-ea07361b26a9"
	statusUUID = "beb5483e-36e1-4688-b7f5-ea07361b26aa"

	appPath    = dbus.ObjectPath("/org/swarm/kismetnode")
	svcPath    = appPath + "/service0"
	cmdPath    = svcPath + "/char0"
	rspPath    = svcPath + "/char1"
	statusPath = svcPath + "/char2"
	advPath    = appPath + "/advert0"

	ifProps   = "org.freedesktop.DBus.Properties"
	ifObjMgr  = "org.freedesktop.DBus.ObjectManager"
	ifService = "org.bluez.GattService1"
	ifChar    = "org.bluez.GattCharacteristic1"
	ifAdv     = "org.bluez.LEAdvertisement1"
	ifAdapter = "org.bluez.Adapter1"
	ifDevice  = "org.bluez.Device1"
)

type BlueZ struct {
	conn    *dbus.Conn
	adapter dbus.ObjectPath
	node    *Node
	every   time.Duration // one notification per this, at most

	mu        sync.Mutex
	notifying bool
	device    dbus.ObjectPath // the phone (learned from its writes)
	mtu       int
	advName   string
	advOn     bool
}

type dbusProps map[string]map[string]dbus.Variant

func newBlueZ(hci string, node *Node, every time.Duration) (*BlueZ, error) {
	conn, err := dbus.ConnectSystemBus()
	if err != nil {
		return nil, fmt.Errorf("can't reach the system bus (is this Linux with BlueZ?): %w", err)
	}
	b := &BlueZ{conn: conn, node: node, every: every, mtu: 23}
	if err := b.findAdapter(hci); err != nil {
		conn.Close()
		return nil, err
	}
	return b, nil
}

// findAdapter picks the Bluetooth adapter (hciN) and reads its address.
func (b *BlueZ) findAdapter(hci string) error {
	var objs map[dbus.ObjectPath]map[string]map[string]dbus.Variant
	if err := b.conn.Object("org.bluez", "/").Call(ifObjMgr+".GetManagedObjects", 0).Store(&objs); err != nil {
		return fmt.Errorf("can't reach bluetoothd (is the bluetooth service running?): %w", err)
	}
	var found []string
	for p, ifs := range objs {
		a, ok := ifs[ifAdapter]
		if !ok {
			continue
		}
		found = append(found, string(p))
		if hci != "" && !strings.HasSuffix(string(p), "/"+hci) {
			continue
		}
		if b.adapter != "" && p > b.adapter { // without -hci, the lowest (hci0)
			continue
		}
		b.adapter = p
		addr, _ := a["Address"].Value().(string)
		var m [6]byte
		if _, err := fmt.Sscanf(addr, "%02X:%02X:%02X:%02X:%02X:%02X", &m[0], &m[1], &m[2], &m[3], &m[4], &m[5]); err == nil {
			b.node.SetMAC(m)
		}
		if t, _ := a["AddressType"].Value().(string); t == "random" {
			logf("warning: %s uses a random address; the owner lock needs its public address", p)
		}
	}
	if b.adapter == "" {
		if hci != "" {
			return fmt.Errorf("no Bluetooth adapter %s (found: %s)", hci, strings.Join(found, ", "))
		}
		return fmt.Errorf("no Bluetooth adapter found")
	}
	return nil
}

func (b *BlueZ) objects() map[dbus.ObjectPath]dbusProps {
	return map[dbus.ObjectPath]dbusProps{
		svcPath: {ifService: {
			"UUID":    dbus.MakeVariant(svcUUID),
			"Primary": dbus.MakeVariant(true),
		}},
		cmdPath: {ifChar: {
			"UUID":    dbus.MakeVariant(cmdUUID),
			"Service": dbus.MakeVariant(svcPath),
			"Flags":   dbus.MakeVariant([]string{"write", "write-without-response"}),
		}},
		rspPath: {ifChar: {
			"UUID":      dbus.MakeVariant(rspUUID),
			"Service":   dbus.MakeVariant(svcPath),
			"Flags":     dbus.MakeVariant([]string{"notify"}),
			"Notifying": dbus.MakeVariant(b.isNotifying()),
		}},
		statusPath: {ifChar: {
			"UUID":    dbus.MakeVariant(statusUUID),
			"Service": dbus.MakeVariant(svcPath),
			"Flags":   dbus.MakeVariant([]string{"read"}),
		}},
	}
}

func (b *BlueZ) isNotifying() bool { b.mu.Lock(); defer b.mu.Unlock(); return b.notifying }

func (b *BlueZ) advProps() map[string]dbus.Variant {
	b.mu.Lock()
	name := b.advName
	b.mu.Unlock()
	return map[string]dbus.Variant{
		"Type":         dbus.MakeVariant("peripheral"),
		"ServiceUUIDs": dbus.MakeVariant([]string{svcUUID}),
		"LocalName":    dbus.MakeVariant(name),
	}
}

// exportProps serves org.freedesktop.DBus.Properties for one object.
func (b *BlueZ) exportProps(path dbus.ObjectPath, get func() map[string]map[string]dbus.Variant) error {
	return b.conn.ExportMethodTable(map[string]interface{}{
		"Get": func(iface, name string) (dbus.Variant, *dbus.Error) {
			if v, ok := get()[iface][name]; ok {
				return v, nil
			}
			return dbus.Variant{}, dbus.NewError("org.freedesktop.DBus.Error.InvalidArgs", []interface{}{"no such property"})
		},
		"GetAll": func(iface string) (map[string]dbus.Variant, *dbus.Error) {
			return get()[iface], nil
		},
		"Set": func(iface, name string, v dbus.Variant) *dbus.Error {
			return dbus.NewError("org.freedesktop.DBus.Error.PropertyReadOnly", []interface{}{name})
		},
	}, path, ifProps)
}

func notSupported() *dbus.Error {
	return dbus.NewError("org.bluez.Error.NotSupported", nil)
}

func (b *BlueZ) export() error {
	c := b.conn
	if err := c.ExportMethodTable(map[string]interface{}{
		"GetManagedObjects": func() (map[dbus.ObjectPath]map[string]map[string]dbus.Variant, *dbus.Error) {
			out := map[dbus.ObjectPath]map[string]map[string]dbus.Variant{}
			for p, v := range b.objects() {
				out[p] = v
			}
			return out, nil
		},
	}, appPath, ifObjMgr); err != nil {
		return err
	}
	for p := range b.objects() {
		p := p
		if err := b.exportProps(p, func() map[string]map[string]dbus.Variant { return b.objects()[p] }); err != nil {
			return err
		}
	}
	// command: the phone's lines
	if err := c.ExportMethodTable(map[string]interface{}{
		"WriteValue": func(value []byte, opts map[string]dbus.Variant) *dbus.Error {
			b.noteWriter(opts)
			b.node.Write(value)
			return nil
		},
		"ReadValue":   func(opts map[string]dbus.Variant) ([]byte, *dbus.Error) { return nil, notSupported() },
		"StartNotify": func() *dbus.Error { return notSupported() },
		"StopNotify":  func() *dbus.Error { return notSupported() },
	}, cmdPath, ifChar); err != nil {
		return err
	}
	// response: notifications to the phone
	if err := c.ExportMethodTable(map[string]interface{}{
		"ReadValue":  func(opts map[string]dbus.Variant) ([]byte, *dbus.Error) { return []byte{}, nil },
		"WriteValue": func(value []byte, opts map[string]dbus.Variant) *dbus.Error { return notSupported() },
		"StartNotify": func() *dbus.Error {
			b.mu.Lock()
			b.notifying = true
			b.mu.Unlock()
			b.node.Connected()
			return nil
		},
		"StopNotify": func() *dbus.Error {
			b.linkDown("unsubscribed")
			return nil
		},
	}, rspPath, ifChar); err != nil {
		return err
	}
	// status: JSON any client can read
	if err := c.ExportMethodTable(map[string]interface{}{
		"ReadValue": func(opts map[string]dbus.Variant) ([]byte, *dbus.Error) {
			v := b.node.Status()
			if off, ok := opts["offset"].Value().(uint16); ok {
				if int(off) >= len(v) {
					return []byte{}, nil
				}
				v = v[off:]
			}
			return v, nil
		},
		"WriteValue":  func(value []byte, opts map[string]dbus.Variant) *dbus.Error { return notSupported() },
		"StartNotify": func() *dbus.Error { return notSupported() },
		"StopNotify":  func() *dbus.Error { return notSupported() },
	}, statusPath, ifChar); err != nil {
		return err
	}
	// advert
	if err := c.ExportMethodTable(map[string]interface{}{
		"Release": func() *dbus.Error {
			b.mu.Lock()
			b.advOn = false
			b.mu.Unlock()
			return nil
		},
	}, advPath, ifAdv); err != nil {
		return err
	}
	return b.exportProps(advPath, func() map[string]map[string]dbus.Variant {
		return map[string]map[string]dbus.Variant{ifAdv: b.advProps()}
	})
}

// noteWriter remembers which phone is writing and the link's MTU (BlueZ 5.62+ passes it).
func (b *BlueZ) noteWriter(opts map[string]dbus.Variant) {
	b.mu.Lock()
	defer b.mu.Unlock()
	if d, ok := opts["device"].Value().(dbus.ObjectPath); ok {
		b.device = d
	}
	if m, ok := opts["mtu"].Value().(uint16); ok && m >= 23 {
		b.mtu = int(m)
	}
}

func (b *BlueZ) linkDown(why string) {
	b.mu.Lock()
	was := b.notifying
	b.notifying = false
	b.device = ""
	b.mtu = 23
	b.mu.Unlock()
	if was {
		logf("phone gone (%s)", why)
		b.node.Disconnected()
	}
}

func (b *BlueZ) adapterObj() dbus.BusObject { return b.conn.Object("org.bluez", b.adapter) }

// Start powers the adapter on, registers the service and starts advertising.
func (b *BlueZ) Start() error {
	a := b.adapterObj()
	if err := a.SetProperty(ifAdapter+".Powered", dbus.MakeVariant(true)); err != nil {
		logf("couldn't power on %s: %v", b.adapter, err)
	}
	if err := b.export(); err != nil {
		return fmt.Errorf("export: %w", err)
	}
	if err := a.Call("org.bluez.GattManager1.RegisterApplication", 0, appPath, map[string]dbus.Variant{}).Err; err != nil {
		return fmt.Errorf("bluetoothd refused the Swarm service: %w", err)
	}
	b.setName(b.node.Slot())
	b.node.onSlot = b.setName
	if err := b.conn.AddMatchSignal(
		dbus.WithMatchInterface(ifProps), dbus.WithMatchMember("PropertiesChanged"),
		dbus.WithMatchPathNamespace("/org/bluez"),
	); err != nil {
		logf("can't watch for disconnects: %v", err)
	}
	return nil
}

// setName (re)starts the advert under the same names a board uses: "WDU0" before it has a number, then
// "WDN<node number>" (nothing in the air tells it apart from a board).
func (b *BlueZ) setName(slot int) {
	name := fmt.Sprintf("WDN%d", slot)
	if slot <= 0 {
		name = "WDU0"
	}
	b.mu.Lock()
	b.advName = name
	b.mu.Unlock()
	b.restartAdvert()
}

func (b *BlueZ) restartAdvert() {
	a := b.adapterObj()
	b.mu.Lock()
	on := b.advOn
	name := b.advName
	b.mu.Unlock()
	if on {
		a.Call("org.bluez.LEAdvertisingManager1.UnregisterAdvertisement", 0, advPath)
	}
	if err := a.Call("org.bluez.LEAdvertisingManager1.RegisterAdvertisement", 0, advPath, map[string]dbus.Variant{}).Err; err != nil {
		logf("advertising failed: %v", err)
		b.mu.Lock()
		b.advOn = false
		b.mu.Unlock()
		return
	}
	b.mu.Lock()
	b.advOn = true
	b.mu.Unlock()
	logf("advertising as %s", name)
}

// Run sends the node's lines as notifications, watches for the phone leaving, and keeps the advert up.
func (b *BlueZ) Run(ctx context.Context) {
	sigs := make(chan *dbus.Signal, 64)
	b.conn.Signal(sigs)
	tick := time.NewTicker(b.every)
	defer tick.Stop()
	check := time.NewTicker(10 * time.Second)
	defer check.Stop()
	for {
		select {
		case <-ctx.Done():
			b.stop()
			return
		case s := <-sigs:
			b.onSignal(s)
		case <-check.C:
			b.mu.Lock()
			lost := !b.advOn && !b.notifying
			b.mu.Unlock()
			if lost {
				b.restartAdvert()
			}
		case <-tick.C:
			b.mu.Lock()
			on, mtu := b.notifying, b.mtu
			b.mu.Unlock()
			if !on {
				continue
			}
			if chunk := b.node.TakeOut(mtu - 3); chunk != nil {
				b.conn.Emit(rspPath, ifProps+".PropertiesChanged", ifChar,
					map[string]dbus.Variant{"Value": dbus.MakeVariant(chunk)}, []string{})
			}
		}
	}
}

func (b *BlueZ) onSignal(s *dbus.Signal) {
	if s.Name != ifProps+".PropertiesChanged" || len(s.Body) < 2 {
		return
	}
	iface, _ := s.Body[0].(string)
	changed, _ := s.Body[1].(map[string]dbus.Variant)
	if iface != ifDevice {
		return
	}
	c, ok := changed["Connected"]
	if !ok {
		return
	}
	if conn, _ := c.Value().(bool); conn {
		return
	}
	b.mu.Lock()
	ours := b.device == "" || b.device == s.Path
	b.mu.Unlock()
	if ours {
		b.linkDown("disconnected")
		// some controllers stop advertising on a connection: start it again
		time.AfterFunc(time.Second, b.restartAdvert)
	}
}

func (b *BlueZ) stop() {
	a := b.adapterObj()
	a.Call("org.bluez.LEAdvertisingManager1.UnregisterAdvertisement", 0, advPath)
	a.Call("org.bluez.GattManager1.UnregisterApplication", 0, appPath)
	b.conn.Close()
}
