package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
)

// Rec is one sighting waiting for the phone. T is this computer's clock (unix seconds); the phone's
// clock offset is applied when it is sent.
type Rec struct {
	Seq  uint32 `json:"q"`
	Sess int    `json:"s"`
	Kind int    `json:"k"` // recWifi or recBLE
	MAC  string `json:"m"`
	Name string `json:"n,omitempty"`
	Ch   int    `json:"c,omitempty"`
	RSSI int    `json:"r"`
	Sec  string `json:"x,omitempty"` // security token (OPEN, WPA2_PSK, ...), Wi-Fi only
	T    int64  `json:"t"`
}

const (
	recWifi = 1
	recBLE  = 2
)

// State is what the node keeps between runs, like a board keeps it in flash (protocol.h).
type State struct {
	Owner    string `json:"owner,omitempty"` // owner key, hex (owner lock)
	Slot     int    `json:"slot"`
	Plan     string `json:"plan,omitempty"` // the plan as the phone sent it (kept so its hash matches)
	Hash     int    `json:"hash"`
	Run      int    `json:"run"`
	Sess     int    `json:"sess"`
	Acked    uint32 `json:"acked"`    // the phone has everything before this seq
	Reserved uint32 `json:"reserved"` // seqs below this may have been used: a restart starts here
	Lost     uint32 `json:"lost"`
}

func loadState(dir string) State {
	var s State
	b, err := os.ReadFile(filepath.Join(dir, "state.json"))
	if err == nil {
		_ = json.Unmarshal(b, &s)
	}
	return s
}

func saveState(dir string, s State) error {
	b, _ := json.MarshalIndent(s, "", "  ")
	tmp := filepath.Join(dir, "state.json.tmp")
	if err := os.WriteFile(tmp, b, 0600); err != nil {
		return err
	}
	return os.Rename(tmp, filepath.Join(dir, "state.json"))
}

// Queue holds sightings until the phone acks them. Kept in memory and in an append-only file
// (queue.log, one JSON record per line), so a power cut or restart loses nothing; the file is
// rewritten without the acked records now and then.
type Queue struct {
	path    string
	f       *os.File
	w       *bufio.Writer
	recs    []Rec // by seq, ascending
	max     int
	stale   int // lines in the file that are acked or dropped
	Lost    uint32
	unsaved bool
}

func openQueue(dir string, max int, acked uint32) (*Queue, uint32, error) {
	q := &Queue{path: filepath.Join(dir, "queue.log"), max: max}
	var top uint32
	if f, err := os.Open(q.path); err == nil {
		sc := bufio.NewScanner(f)
		sc.Buffer(make([]byte, 64*1024), 1024*1024)
		for sc.Scan() {
			var r Rec
			if json.Unmarshal(sc.Bytes(), &r) != nil {
				continue // a line cut short by a power cut
			}
			if r.Seq+1 > top {
				top = r.Seq + 1
			}
			if r.Seq >= acked {
				q.recs = append(q.recs, r)
			}
		}
		f.Close()
	}
	sort.Slice(q.recs, func(i, j int) bool { return q.recs[i].Seq < q.recs[j].Seq })
	for len(q.recs) > q.max {
		q.recs = q.recs[1:]
		q.Lost++
	}
	if err := q.rewrite(); err != nil {
		return nil, 0, err
	}
	return q, top, nil
}

// rewrite writes the file again with just the records still held.
func (q *Queue) rewrite() error {
	if q.f != nil {
		q.w.Flush()
		q.f.Close()
	}
	tmp := q.path + ".tmp"
	f, err := os.OpenFile(tmp, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0600)
	if err != nil {
		return err
	}
	w := bufio.NewWriter(f)
	for _, r := range q.recs {
		b, _ := json.Marshal(r)
		w.Write(b)
		w.WriteByte('\n')
	}
	if err := w.Flush(); err != nil {
		f.Close()
		return err
	}
	f.Close()
	if err := os.Rename(tmp, q.path); err != nil {
		return err
	}
	q.f, err = os.OpenFile(q.path, os.O_APPEND|os.O_WRONLY, 0600)
	if err != nil {
		return fmt.Errorf("queue file: %w", err)
	}
	q.w = bufio.NewWriterSize(q.f, 64*1024)
	q.stale = 0
	return nil
}

func (q *Queue) Add(r Rec) {
	if len(q.recs) >= q.max { // full: the oldest goes (counted as lost, like a board)
		q.recs = q.recs[1:]
		q.Lost++
		q.stale++
	}
	q.recs = append(q.recs, r)
	b, _ := json.Marshal(r)
	q.w.Write(b)
	q.w.WriteByte('\n')
	q.unsaved = true
}

// Ack drops everything before seq n.
func (q *Queue) Ack(n uint32) {
	i := sort.Search(len(q.recs), func(i int) bool { return q.recs[i].Seq >= n })
	if i == 0 {
		return
	}
	q.recs = q.recs[i:]
	q.stale += i
	if q.stale > 5000 && q.stale > len(q.recs) {
		if err := q.rewrite(); err != nil {
			logf("queue: rewrite failed: %v", err)
		}
	}
}

// From returns up to n records starting at seq.
func (q *Queue) From(seq uint32, n int) []Rec {
	i := sort.Search(len(q.recs), func(i int) bool { return q.recs[i].Seq >= seq })
	j := i + n
	if j > len(q.recs) {
		j = len(q.recs)
	}
	return q.recs[i:j]
}

func (q *Queue) Len() int { return len(q.recs) }

// Oldest is the seq of the oldest record held, or next when empty.
func (q *Queue) Oldest(next uint32) uint32 {
	if len(q.recs) == 0 {
		return next
	}
	return q.recs[0].Seq
}

// Sync writes buffered records to disk.
func (q *Queue) Sync() {
	if !q.unsaved {
		return
	}
	q.unsaved = false
	if err := q.w.Flush(); err != nil {
		logf("queue: write failed: %v", err)
		return
	}
	q.f.Sync()
}

func (q *Queue) Close() {
	q.Sync()
	q.f.Close()
}
