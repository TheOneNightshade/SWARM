package main

import (
	"bufio"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"regexp"
	"strconv"
	"strings"
	"time"
)

// ---------------------------------------------------------------- shared helpers

var macRe = regexp.MustCompile(`^[0-9A-Fa-f]{2}(:[0-9A-Fa-f]{2}){5}$`)

func normMAC(s string) (string, bool) {
	s = strings.TrimSpace(s)
	if !macRe.MatchString(s) {
		return "", false
	}
	return strings.ToUpper(s), true
}

// freqChannel turns a frequency in MHz into a Wi-Fi channel the app can log (2.4 and 5 GHz). 0 = none
// (6 GHz channel numbers would collide with 2.4 GHz ones in the app's log, so they are left out).
func freqChannel(mhz int) int {
	switch {
	case mhz == 2484:
		return 14
	case mhz >= 2412 && mhz <= 2472:
		return (mhz - 2407) / 5
	case mhz >= 5160 && mhz <= 5885:
		return (mhz - 5000) / 5
	}
	return 0
}

var leadInt = regexp.MustCompile(`^\s*(\d+)`)

// channelOf picks the channel from Kismet's frequency (kHz or MHz) or, failing that, its channel text
// ("6", "36", "6HT40+").
func channelOf(freq float64, ch string) int {
	f := int(freq)
	if f > 100000 { // kHz
		f /= 1000
	}
	if f > 0 {
		if c := freqChannel(f); c > 0 {
			return c
		}
		if f >= 5925 { // 6 GHz
			return 0
		}
	}
	if m := leadInt.FindStringSubmatch(ch); m != nil {
		c, _ := strconv.Atoi(m[1])
		if (c >= 1 && c <= 14) || (c >= 32 && c <= 177) {
			return c
		}
	}
	return 0
}

var wpa1Re = regexp.MustCompile(`WPA($|[^23])`)

// secToken maps Kismet's encryption text ("WPA2-PSK", "WPA2 WPA3-SAE", "Open", ...) or a WiGLE
// capability string ("[WPA2-PSK-CCMP][ESS]") to the security token the node protocol uses.
func secToken(s string) string {
	u := strings.ToUpper(s)
	wpa3 := strings.Contains(u, "WPA3") || strings.Contains(u, "SAE")
	wpa2 := strings.Contains(u, "WPA2") || strings.Contains(u, "RSN")
	wpa1 := wpa1Re.MatchString(u)
	eap := strings.Contains(u, "EAP") || strings.Contains(u, "802.1X") || strings.Contains(u, "ENTERPRISE") || strings.Contains(u, "MGT")
	switch {
	case strings.Contains(u, "OWE"):
		return "OWE"
	case eap && wpa3 && !wpa2:
		return "WPA3_ENTERPRISE"
	case eap:
		return "WPA2_ENTERPRISE"
	case wpa3 && wpa2:
		return "WPA2_WPA3_PSK"
	case wpa3:
		return "WPA3_PSK"
	case wpa1 && wpa2:
		return "WPA_WPA2_PSK"
	case wpa2:
		return "WPA2_PSK"
	case wpa1:
		return "WPA_PSK"
	case strings.Contains(u, "WEP"):
		return "WEP"
	}
	return "OPEN"
}

// ---------------------------------------------------------------- Kismet REST feed

// KismetFeed asks Kismet's REST API, every [poll], for the devices it heard since the last ask. That
// needs no GPS on this computer: the phone places each sighting with its own GPS track.
type KismetFeed struct {
	base   string
	user   string
	pass   string
	apikey string
	poll   time.Duration
	client *http.Client
	since  int64 // Kismet's clock, seconds
}

var kismetFields = [][2]string{
	{"kismet.device.base.macaddr", "mac"},
	{"kismet.device.base.phyname", "phy"},
	{"kismet.device.base.type", "type"},
	{"kismet.device.base.commonname", "name"},
	{"kismet.device.base.channel", "channel"},
	{"kismet.device.base.frequency", "freq"},
	{"kismet.device.base.signal/kismet.common.signal.last_signal", "rssi"},
	{"kismet.device.base.crypt", "crypt"},
	{"kismet.device.base.last_time", "last"},
}

type kismetDev struct {
	MAC     string      `json:"mac"`
	Phy     string      `json:"phy"`
	Type    string      `json:"type"`
	Name    string      `json:"name"`
	Channel string      `json:"channel"`
	Freq    json.Number `json:"freq"`
	RSSI    json.Number `json:"rssi"`
	Crypt   any         `json:"crypt"`
	Last    json.Number `json:"last"`
}

func (k *KismetFeed) Run(ctx context.Context, n *Node) {
	k.client = &http.Client{Timeout: 15 * time.Second}
	down := false
	for {
		devs, err := k.fetch(ctx)
		if ctx.Err() != nil {
			return
		}
		wait := k.poll
		if err != nil {
			if !down {
				logf("kismet: %v (trying again every 5 s)", err)
			}
			down = true
			wait = 5 * time.Second
		} else {
			if down {
				logf("kismet: reading again")
			}
			down = false
			for _, d := range devs {
				if r, ok := d.rec(); ok {
					n.Add(r)
				}
			}
		}
		select {
		case <-ctx.Done():
			return
		case <-time.After(wait):
		}
	}
}

func (k *KismetFeed) fetch(ctx context.Context) ([]kismetDev, error) {
	ts := "-30" // first ask: the last 30 seconds
	if k.since > 0 {
		ts = strconv.FormatInt(k.since-2, 10)
	}
	var fields []any
	for _, f := range kismetFields {
		fields = append(fields, []string{f[0], f[1]})
	}
	body, _ := json.Marshal(map[string]any{"fields": fields})
	form := url.Values{"json": {string(body)}}
	req, err := http.NewRequestWithContext(ctx, "POST", k.base+"/devices/last-time/"+ts+"/devices.json",
		strings.NewReader(form.Encode()))
	if err != nil {
		return nil, err
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	if k.apikey != "" {
		req.AddCookie(&http.Cookie{Name: "KISMET", Value: k.apikey})
	} else if k.user != "" {
		req.SetBasicAuth(k.user, k.pass)
	}
	resp, err := k.client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode == 401 || resp.StatusCode == 403 {
		return nil, fmt.Errorf("login refused (HTTP %d): check -user/-pass or -apikey", resp.StatusCode)
	}
	if resp.StatusCode != 200 {
		b, _ := io.ReadAll(io.LimitReader(resp.Body, 200))
		return nil, fmt.Errorf("HTTP %d: %s", resp.StatusCode, strings.TrimSpace(string(b)))
	}
	dec := json.NewDecoder(resp.Body)
	dec.UseNumber()
	var devs []kismetDev
	if err := dec.Decode(&devs); err != nil {
		return nil, fmt.Errorf("unexpected reply: %v", err)
	}
	for _, d := range devs {
		if t, err := d.Last.Int64(); err == nil && t > k.since {
			k.since = t
		}
	}
	return devs, nil
}

func numInt(n json.Number) int {
	if f, err := n.Float64(); err == nil {
		return int(f)
	}
	return 0
}

func (d kismetDev) rec() (Rec, bool) {
	mac, ok := normMAC(d.MAC)
	if !ok {
		return Rec{}, false
	}
	name := d.Name
	if strings.EqualFold(strings.TrimSpace(name), mac) {
		name = "" // Kismet shows the address when there is no name (a hidden network)
	}
	last, _ := d.Last.Int64()
	r := Rec{MAC: mac, Name: name, RSSI: numInt(d.RSSI), T: last}
	phy := strings.ToUpper(d.Phy)
	typ := strings.ToUpper(d.Type)
	switch {
	case strings.Contains(phy, "802.11"):
		if typ != "WI-FI AP" {
			return Rec{}, false // clients, bridges and probes aren't logged (WiGLE wants access points)
		}
		f, _ := d.Freq.Float64()
		r.Kind = recWifi
		r.Ch = channelOf(f, d.Channel)
		if r.Ch == 0 {
			return Rec{}, false
		}
		crypt := ""
		switch c := d.Crypt.(type) {
		case string:
			crypt = c
		}
		r.Sec = secToken(crypt)
	case strings.Contains(phy, "BLUETOOTH") || strings.Contains(phy, "BTLE") || strings.Contains(typ, "BTLE") || strings.Contains(typ, "BR/EDR"):
		r.Kind = recBLE
	default:
		return Rec{}, false // other radios (433 MHz sensors, ADS-B, Zigbee...) have no place in a WiGLE log
	}
	if r.RSSI < -128 || r.RSSI > 127 {
		r.RSSI = 0
	}
	return r, true
}

// ---------------------------------------------------------------- piped feed (standard input)

// PipeFeed reads sightings piped in, one per line: WiGLE CSV rows (e.g. `tail -F` of Kismet's wiglecsv
// log) or JSON lines {"type":"wifi","mac":...,"ssid":...,"channel":6,"rssi":-70,"security":"WPA2"}.
type PipeFeed struct{ in io.Reader }

type pipeJSON struct {
	Type     string  `json:"type"`
	MAC      string  `json:"mac"`
	SSID     string  `json:"ssid"`
	Name     string  `json:"name"`
	Ch       any     `json:"channel"`
	Freq     float64 `json:"freq"`
	RSSI     float64 `json:"rssi"`
	Security string  `json:"security"`
	Time     int64   `json:"time"`
}

func (p *PipeFeed) Run(ctx context.Context, n *Node) {
	sc := bufio.NewScanner(p.in)
	sc.Buffer(make([]byte, 64*1024), 1024*1024)
	cols := map[string]int{"MAC": 0, "SSID": 1, "AUTHMODE": 2, "FIRSTSEEN": 3, "CHANNEL": 4, "RSSI": 5, "TYPE": 10}
	for sc.Scan() {
		if ctx.Err() != nil {
			return
		}
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "WigleWifi") || strings.HasPrefix(line, "==>") {
			continue
		}
		if strings.HasPrefix(line, "{") {
			if r, ok := parsePipeJSON(line); ok {
				n.Add(r)
			}
			continue
		}
		f := splitCSV(line)
		if len(f) > 0 && strings.EqualFold(f[0], "MAC") { // a header: learn where each column is
			cols = map[string]int{}
			for i, c := range f {
				cols[strings.ToUpper(strings.TrimSpace(c))] = i
			}
			continue
		}
		if r, ok := parseWigleRow(f, cols); ok {
			n.Add(r)
		}
	}
	if err := sc.Err(); err != nil {
		logf("input: %v", err)
	}
	logf("input ended")
}

func col(f []string, cols map[string]int, k string) string {
	i, ok := cols[k]
	if !ok || i >= len(f) {
		return ""
	}
	return strings.TrimSpace(f[i])
}

func parseWigleRow(f []string, cols map[string]int) (Rec, bool) {
	mac, ok := normMAC(col(f, cols, "MAC"))
	if !ok {
		return Rec{}, false
	}
	rssi, _ := strconv.Atoi(col(f, cols, "RSSI"))
	r := Rec{MAC: mac, Name: col(f, cols, "SSID"), RSSI: rssi, T: time.Now().Unix()}
	switch strings.ToUpper(col(f, cols, "TYPE")) {
	case "WIFI", "":
		r.Kind = recWifi
		freq, _ := strconv.ParseFloat(col(f, cols, "FREQUENCY"), 64)
		r.Ch = channelOf(freq, col(f, cols, "CHANNEL"))
		if r.Ch == 0 {
			return Rec{}, false
		}
		r.Sec = secToken(col(f, cols, "AUTHMODE"))
	case "BLE", "BT":
		r.Kind = recBLE
	default:
		return Rec{}, false
	}
	return r, true
}

func parsePipeJSON(line string) (Rec, bool) {
	var j pipeJSON
	if json.Unmarshal([]byte(line), &j) != nil {
		return Rec{}, false
	}
	mac, ok := normMAC(j.MAC)
	if !ok {
		return Rec{}, false
	}
	r := Rec{MAC: mac, RSSI: int(j.RSSI), T: j.Time}
	if r.T == 0 {
		r.T = time.Now().Unix()
	}
	switch strings.ToLower(j.Type) {
	case "wifi", "ap", "wi-fi":
		r.Kind = recWifi
		r.Name = j.SSID
		if r.Name == "" {
			r.Name = j.Name
		}
		ch := ""
		switch c := j.Ch.(type) {
		case float64:
			ch = strconv.Itoa(int(c))
		case string:
			ch = c
		}
		r.Ch = channelOf(j.Freq, ch)
		if r.Ch == 0 {
			return Rec{}, false
		}
		r.Sec = secToken(j.Security)
	case "ble", "bt", "bluetooth":
		r.Kind = recBLE
		r.Name = j.Name
	default:
		return Rec{}, false
	}
	return r, true
}

// splitCSV splits one CSV line, honouring double quotes (SSIDs can hold commas).
func splitCSV(s string) []string {
	var out []string
	var b strings.Builder
	q := false
	for i := 0; i < len(s); i++ {
		c := s[i]
		switch {
		case q && c == '"' && i+1 < len(s) && s[i+1] == '"':
			b.WriteByte('"')
			i++
		case c == '"':
			q = !q
		case c == ',' && !q:
			out = append(out, b.String())
			b.Reset()
		default:
			b.WriteByte(c)
		}
	}
	return append(out, b.String())
}
