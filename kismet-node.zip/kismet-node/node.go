package main

import (
	"bytes"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"
)

// Protocol constants, mirrored from firmware/wd_swarm_node/protocol.h.
const (
	protoVer = 6

	beatRunning = 0x01
	beat5G      = 0x08
	beatFlash   = 0x10
	beatSynced  = 0x20
	beatOwned   = 0x40
	beatKismet  = 0x80 // a Kismet node, not a board

	statusReady = 1
	statusBusy  = 2

	beatEvery    = 3 * time.Second
	timeReqEvery = 5 * time.Second
	reserveStep  = 1000             // seqs reserved at a time, so a restart never reuses one
	rewindAfter  = 10 * time.Second // sent ahead of the ack and no ack for this long: send again
	outboxMax    = 4096             // stop filling the outbox past this (the link drains it)
	nameMax      = 32
)

// Node speaks the Swarm node protocol (text lines over the GATT link) for the Kismet feed. The Bluetooth
// side (bluez.go) hands it what the phone writes and drains what it says; the feeds call Add.
type Node struct {
	mu  sync.Mutex
	dir string
	st  State
	q   *Queue
	key []byte // owner key (nil: no owner yet)
	mac [6]byte
	f   *Filter

	next uint32 // seq the next sighting gets

	// link
	linked    bool
	ext       bool    // said hello
	seal      *sealer // the phone proved the owner key: every line both ways is sealed (seal.go)
	nonce     [8]byte
	nonceOut  bool
	cursor    uint32 // next seq to send
	ackMoved  time.Time
	out       bytes.Buffer
	synced    bool  // the phone set our clock since start
	offset    int64 // phone time minus this computer's time, seconds
	beatNow   bool
	nextBeat  time.Time
	nextTime  time.Time
	dirty     bool
	lastSave  time.Time
	lastSync  time.Time
	onSlot    func(int) // the node number changed (the advert name shows it)
	statusStr string

	// counters for the log line
	added, ignored, sent int
}

func newNode(dir string, maxQueue int, resend time.Duration) (*Node, error) {
	n := &Node{dir: dir, st: loadState(dir), f: newFilter(resend)}
	q, top, err := openQueue(dir, maxQueue, n.st.Acked)
	if err != nil {
		return nil, err
	}
	n.q = q
	q.Lost += n.st.Lost
	n.next = maxU32(n.st.Reserved, n.st.Acked, top)
	n.st.Reserved = n.next + reserveStep
	if n.st.Owner != "" {
		if k, err := hex.DecodeString(n.st.Owner); err == nil && len(k) == 16 {
			n.key = k
		}
	}
	n.cursor = q.Oldest(n.next)
	if err := saveState(dir, n.st); err != nil {
		return nil, err
	}
	return n, nil
}

func maxU32(v ...uint32) uint32 {
	m := uint32(0)
	for _, x := range v {
		if x > m {
			m = x
		}
	}
	return m
}

// SetMAC sets this computer's Bluetooth address (the owner challenge includes it).
func (n *Node) SetMAC(m [6]byte) { n.mu.Lock(); n.mac = m; n.mu.Unlock() }

func (n *Node) Slot() int { n.mu.Lock(); defer n.mu.Unlock(); return n.st.Slot }

// ForgetOwner frees the node for another phone (like holding BOOT on a board).
func (n *Node) ForgetOwner() error {
	n.mu.Lock()
	defer n.mu.Unlock()
	n.key = nil
	n.st.Owner = ""
	return saveState(n.dir, n.st)
}

func (n *Node) OwnerText() string {
	n.mu.Lock()
	defer n.mu.Unlock()
	if n.key == nil {
		return "no owner yet (the first Swarm app to link takes it)"
	}
	return fmt.Sprintf("owner id %04x", ownerID(n.key))
}

// ---------------------------------------------------------------- owner lock (wd_auth.h, Owner.kt)

func hmac256(key []byte, parts ...[]byte) []byte {
	m := hmac.New(sha256.New, key)
	for _, p := range parts {
		m.Write(p)
	}
	return m.Sum(nil)
}

func ownerID(key []byte) int {
	h := hmac256(key, []byte("swarm-owner"))
	return int(h[0]) | int(h[1])<<8
}

func helloTag(key, nonce []byte, mac [6]byte) []byte {
	return hmac256(key, []byte("hello"), nonce, mac[:])[:8]
}

// ---------------------------------------------------------------- link events

// Connected: the phone subscribed to the response characteristic.
func (n *Node) Connected() {
	n.mu.Lock()
	defer n.mu.Unlock()
	n.linked = true
	n.ext = false
	n.seal = nil
	n.nonceOut = false
	n.out.Reset()
	n.nextTime = time.Now().Add(1500 * time.Millisecond) // our phone sends the time straight away
	logf("phone linked")
}

func (n *Node) Disconnected() {
	n.mu.Lock()
	defer n.mu.Unlock()
	if !n.linked {
		return
	}
	n.linked = false
	n.ext = false
	n.seal = nil
	n.out.Reset()
	logf("phone link closed; holding sightings (%d queued)", n.q.Len())
}

func (n *Node) say(format string, a ...any) {
	n.put(fmt.Sprintf(format, a...))
}

// put queues one line (without its \n) for the phone, sealed once the link is.
func (n *Node) put(line string) {
	if n.seal != nil {
		n.out.WriteString(n.seal.close(line))
		return
	}
	n.out.WriteString(line)
	n.out.WriteByte('\n')
}

// TakeOut returns up to max bytes the node wants to send (nil when nothing).
func (n *Node) TakeOut(max int) []byte {
	n.mu.Lock()
	defer n.mu.Unlock()
	if n.out.Len() == 0 || !n.linked {
		return nil
	}
	if max > n.out.Len() {
		max = n.out.Len()
	}
	b := make([]byte, max)
	n.out.Read(b)
	return b
}

// Write takes what the phone wrote to the command characteristic: one or more lines.
func (n *Node) Write(b []byte) {
	n.mu.Lock()
	defer n.mu.Unlock()
	if len(b) > 512 {
		return
	}
	for _, l := range strings.Split(string(b), "\n") {
		l = strings.TrimRight(l, "\r")
		if l == "" {
			continue
		}
		if n.seal != nil { // sealed: nothing else counts
			t, ok := n.seal.open(l)
			if !ok {
				continue
			}
			l = t
		} else if strings.HasPrefix(l, "~") {
			continue
		}
		n.handleLine(l)
	}
}

func split3(s string) (string, string, string, bool) {
	a := strings.IndexByte(s, ':')
	if a < 0 {
		return "", "", "", false
	}
	rest := s[a+1:]
	b := strings.IndexByte(rest, ':')
	if b < 0 {
		return s[:a], rest, "", true
	}
	return s[:a], rest[:b], rest[b+1:], true
}

func arg(args, k string) (string, bool) {
	for _, p := range strings.Split(args, ",") {
		if strings.HasPrefix(p, k+"=") {
			return p[len(k)+1:], true
		}
	}
	return "", false
}

func argInt(args, k string) (int64, bool) {
	v, ok := arg(args, k)
	if !ok {
		return 0, false
	}
	x, err := strconv.ParseInt(v, 10, 64)
	return x, err == nil
}

func (n *Node) handleLine(line string) {
	typ, sub, a, ok := split3(line)
	if !ok {
		return
	}
	locked := n.key != nil && n.seal == nil
	if typ == "TIME" {
		if sub != "SYNC" || locked {
			return
		}
		t, err := time.Parse(time.RFC3339, a)
		if err != nil {
			return
		}
		n.offset = t.Unix() - time.Now().Unix()
		if !n.synced {
			logf("clock set by the phone (this computer is %+d s off)", -n.offset)
		}
		n.synced = true
		n.beatNow = true
		return
	}
	if typ != "CMD" {
		return
	}
	if locked && sub != "hello" && sub != "ping" {
		if sub != "ack" {
			n.say("RSP:%s:ERROR:owned", sub)
		}
		return
	}
	switch sub {
	case "ack":
		v, ok := argInt(a, "n")
		if !ok || v < 0 {
			return
		}
		if s := uint32(v); s > n.st.Acked {
			n.st.Acked = s
			n.q.Ack(s)
			n.ackMoved = time.Now()
			n.dirty = true
		}
		return // no reply, no beat
	case "hello":
		if n.key != nil && n.seal == nil {
			okTag := false
			if t, ok := arg(a, "a"); ok && n.nonceOut {
				if got, err := hex.DecodeString(t); err == nil && len(got) == 8 {
					okTag = hmac.Equal(got, helloTag(n.key, n.nonce[:], n.mac))
				}
			}
			n.nonceOut = false
			if !okTag { // a new challenge each time: answers can't be replayed
				rand.Read(n.nonce[:])
				n.nonceOut = true
				n.say("RSP:hello:ERROR:owned,o=%04x,c=%s", ownerID(n.key), hex.EncodeToString(n.nonce[:]))
				logf("phone said hello without the owner key: refused")
				return
			}
			if e, _ := arg(a, "e"); e != "1" {
				n.say("RSP:hello:ERROR:update the Swarm app")
				logf("phone proved the owner key but its app is too old to talk to this node: update the Swarm app")
				return
			}
			n.say("RSP:hello:OK:e=1")
			n.seal = newSealer(n.key, n.nonce[:], n.mac)
			logf("phone proved the owner key")
		} else {
			n.say("RSP:hello:OK")
		}
		n.ext = true
		n.cursor = n.q.Oldest(n.next) // upload from the oldest sighting the phone hasn't acked
		n.ackMoved = time.Now()
		logf("phone said hello")
	case "plan":
		// Kismet decides what this node scans: the plan is only kept so its hash matches the phone's.
		f, ok := argInt(a, "f")
		if !ok {
			n.say("RSP:plan:ERROR:no f")
			return
		}
		ch, _ := arg(a, "ch")
		n.st.Plan = a
		n.st.Hash = planHash(int(f), ch)
		n.dirty = true
		n.say("RSP:plan:OK")
	case "run":
		m, ok := argInt(a, "m")
		if !ok {
			n.say("RSP:run:ERROR:no m")
			return
		}
		s, ok := argInt(a, "s")
		if !ok {
			s = int64(n.st.Sess)
		}
		n.setRun(int(m)&3, int(s))
		n.say("RSP:run:OK")
		n.sayStatus()
	case "slot":
		v, ok := argInt(a, "n")
		if !ok {
			n.say("RSP:slot:ERROR:no n")
			return
		}
		if int(v) != n.st.Slot {
			n.st.Slot = int(v)
			n.dirty = true
			logf("node number %d", v)
			if n.onSlot != nil {
				go n.onSlot(int(v))
			}
		}
		n.say("RSP:slot:OK")
	case "own":
		k, _ := arg(a, "k")
		key, err := hex.DecodeString(k)
		if err != nil || len(key) != 16 {
			n.say("RSP:own:ERROR:bad key")
			return
		}
		if n.key != nil && !hmac.Equal(key, n.key) {
			n.say("RSP:own:ERROR:owned")
			return
		}
		if n.key == nil {
			n.key = key
			n.st.Owner = hex.EncodeToString(key)
			n.dirty = true
			logf("locked to owner %04x", ownerID(key))
		}
		n.say("RSP:own:OK") // the phone says hello again with the key before anything else goes
	case "disown":
		n.key = nil
		n.st.Owner = ""
		n.dirty = true
		logf("owner forgotten by the phone")
		n.say("RSP:disown:OK")
	case "ping":
		n.say("RSP:ping:OK")
	case "ota":
		n.say("RSP:ota:ERROR:a Kismet node: update the program on the Linux box")
		return
	case "stopscan":
		n.setRun(0, n.st.Sess)
		n.say("RSP:stopscan:OK")
		n.sayStatus()
	case "wardrive", "wardrive5g", "btwardrive", "wardriveall":
		m := 0
		switch sub {
		case "wardrive", "wardrive5g":
			m = 1
		case "btwardrive":
			m = 2
		default:
			m = 3
		}
		n.setRun(m, n.st.Sess)
		n.say("RSP:%s:OK", sub)
		n.say("STATUS:%d:Scan started: %s", statusBusy, sub)
	default:
		n.say("RSP:%s:ERROR:unknown command", sub)
		return
	}
	n.beatNow = true
}

func (n *Node) setRun(m, s int) {
	if m == n.st.Run && s == n.st.Sess {
		return
	}
	if s != n.st.Sess {
		n.f.Reset() // a new scan logs every device again
	}
	n.st.Run, n.st.Sess = m, s
	n.dirty = true
	if m == 0 {
		logf("scan stopped: Kismet's sightings are ignored until the next scan")
	} else {
		logf("scan %d running (%s): sending Kismet's sightings", s, maskText(m))
	}
}

func maskText(m int) string {
	switch m {
	case 1:
		return "Wi-Fi"
	case 2:
		return "BLE"
	default:
		return "Wi-Fi + BLE"
	}
}

func (n *Node) sayStatus() {
	if n.st.Run != 0 {
		n.say("STATUS:%d:Scanning", statusBusy)
	} else {
		n.say("STATUS:%d:Ready", statusReady)
	}
}

// planHash is wd_hash() / Wd.hash(): FNV-1a over flags, count and each channel and dwell, folded to 16 bits.
func planHash(flags int, ch string) int {
	var ent [][2]int
	for _, e := range strings.Split(ch, "/") {
		if e == "" {
			continue
		}
		p := strings.SplitN(e, ".", 2)
		c, err1 := strconv.Atoi(p[0])
		d := 0
		var err2 error
		if len(p) == 2 {
			d, err2 = strconv.Atoi(p[1])
		}
		if err1 != nil || err2 != nil {
			continue
		}
		ent = append(ent, [2]int{c, d})
	}
	if len(ent) > 48 {
		ent = ent[:48]
	}
	h := uint32(2166136261)
	mix := func(b int) { h = (h ^ uint32(b&0xFF)) * 16777619 }
	mix(flags & 3)
	mix(len(ent))
	for _, e := range ent {
		mix(e[0])
		mix(e[1])
	}
	return int(((h >> 16) ^ (h & 0xFFFF)) & 0xFFFF)
}

// ---------------------------------------------------------------- sightings in

// Add takes one sighting from Kismet. It is queued only while the phone's scan runs (the run state is
// kept, so with the phone away it keeps queueing) and only for the sensors that scan picked.
func (n *Node) Add(r Rec) bool {
	n.mu.Lock()
	defer n.mu.Unlock()
	if n.st.Run == 0 || (r.Kind == recWifi && n.st.Run&1 == 0) || (r.Kind == recBLE && n.st.Run&2 == 0) {
		n.ignored++
		return false
	}
	if !n.f.Pass(r, time.Now()) {
		return false
	}
	r.Seq = n.next
	r.Sess = n.st.Sess
	n.next++
	if n.next >= n.st.Reserved {
		n.st.Reserved = n.next + reserveStep
		n.dirty = true
		n.saveLocked()
	}
	n.q.Add(r)
	n.added++
	return true
}

// ---------------------------------------------------------------- tick

// Tick runs every few tens of milliseconds: clock requests, heartbeats, upload and saving.
func (n *Node) Tick(now time.Time) {
	n.mu.Lock()
	defer n.mu.Unlock()
	authorized := n.key == nil || n.seal != nil
	if n.linked && authorized && !n.synced && now.After(n.nextTime) {
		n.nextTime = now.Add(timeReqEvery)
		n.say("TIME:REQUEST:")
	}
	if n.linked && n.ext && authorized && (n.beatNow || now.After(n.nextBeat)) && n.out.Len() < outboxMax {
		n.beatNow = false
		n.nextBeat = now.Add(beatEvery)
		n.sayBeat()
	}
	if n.linked && n.ext && n.seal != nil && n.synced { // sightings only ever go sealed
		n.pump(now)
	}
	if n.dirty && now.Sub(n.lastSave) > time.Second {
		n.saveLocked()
	}
	if now.Sub(n.lastSync) > 3*time.Second {
		n.lastSync = now
		n.q.Sync()
	}
}

func (n *Node) saveLocked() {
	n.lastSave = time.Now()
	n.dirty = false
	n.st.Lost = n.q.Lost
	if err := saveState(n.dir, n.st); err != nil {
		logf("state: save failed: %v", err)
	}
}

func (n *Node) flags() int {
	f := beat5G | beatFlash | beatKismet
	if n.st.Run != 0 {
		f |= beatRunning
	}
	if n.synced {
		f |= beatSynced
	}
	if n.key != nil {
		f |= beatOwned
	}
	return f
}

func (n *Node) sayBeat() {
	n.say("DATA:BEAT:f=%d,h=%d,m=%d,s=%d,n=%d,b=%d,l=%d,q=%d,t=%d,k=%d,bv=0,tc=%d,up=%d",
		n.flags(), n.st.Hash, n.st.Run, n.st.Sess, n.st.Slot, n.q.Len(), n.q.Lost, n.next,
		n.q.Oldest(n.next), Build, cpuTemp(), uptimeMin())
}

// pump puts queued sightings into the outbox while it has room. It walks forward from the oldest unacked
// one; if the phone stops acking what was sent, it starts over from the ack.
func (n *Node) pump(now time.Time) {
	oldest := n.q.Oldest(n.next)
	if n.cursor < oldest {
		n.cursor = oldest
	}
	if n.cursor > oldest && now.Sub(n.ackMoved) > rewindAfter && n.out.Len() == 0 {
		n.cursor = oldest
		n.ackMoved = now
	}
	for n.out.Len() < outboxMax {
		recs := n.q.From(n.cursor, 16)
		if len(recs) == 0 {
			return
		}
		for _, r := range recs {
			n.put(strings.TrimSuffix(n.line(r), "\n"))
			n.cursor = r.Seq + 1
			n.sent++
		}
	}
}

func safeName(s string) string {
	b := []byte(s)
	if len(b) > nameMax {
		b = b[:nameMax]
	}
	for i, c := range b {
		if c == ',' || c == '\r' || c == '\n' || c == 0 {
			b[i] = '_'
		}
	}
	return strings.ToValidUTF8(string(b), "_")
}

func (n *Node) line(r Rec) string {
	t := r.T + n.offset
	if r.T == 0 {
		t = 0
	}
	if r.Kind == recWifi {
		sec := r.Sec
		if sec == "" {
			sec = "UNKNOWN"
		}
		return fmt.Sprintf("DATA:AP:%s,%s,%d,%d,[%s],q=%d,t=%d,s=%d\n", safeName(r.Name), r.MAC, r.Ch, r.RSSI, sec, r.Seq, t, r.Sess)
	}
	return fmt.Sprintf("DATA:BT:%s,%s,%d,BLE,q=%d,t=%d,s=%d\n", safeName(r.Name), r.MAC, r.RSSI, r.Seq, t, r.Sess)
}

// Status is the JSON the status characteristic shows (any client can read it).
func (n *Node) Status() []byte {
	n.mu.Lock()
	defer n.mu.Unlock()
	st, op := statusReady, "idle"
	if n.st.Run != 0 {
		st, op = statusBusy, "wardrive"
	}
	// anyone can read it: nothing here says what this node is
	return []byte(fmt.Sprintf(`{"status":%d,"battery":-1,"op":"%s"}`, st, op))
}

// Report is the once-a-minute log line.
func (n *Node) Report() string {
	n.mu.Lock()
	defer n.mu.Unlock()
	link := "no phone"
	if n.linked && n.ext {
		link = "phone linked"
	} else if n.linked {
		link = "phone connecting"
	}
	run := "not scanning (ignoring Kismet)"
	if n.st.Run != 0 {
		run = "scan " + strconv.Itoa(n.st.Sess) + " (" + maskText(n.st.Run) + ")"
	}
	s := fmt.Sprintf("node %d, %s, %s: %d new sightings queued, %d ignored, %d sent, %d waiting for the phone, %d lost",
		n.st.Slot, link, run, n.added, n.ignored, n.sent, n.q.Len(), n.q.Lost)
	n.added, n.ignored, n.sent = 0, 0, 0
	return s
}

func (n *Node) Close() {
	n.mu.Lock()
	defer n.mu.Unlock()
	n.q.Close()
	n.saveLocked()
}

// ---------------------------------------------------------------- health

func cpuTemp() int {
	b, err := os.ReadFile("/sys/class/thermal/thermal_zone0/temp")
	if err != nil {
		return -128
	}
	v, err := strconv.Atoi(strings.TrimSpace(string(b)))
	if err != nil {
		return -128
	}
	return v / 1000
}

func uptimeMin() int {
	b, err := os.ReadFile("/proc/uptime")
	if err != nil {
		return 0
	}
	f := strings.Fields(string(b))
	if len(f) == 0 {
		return 0
	}
	s, _ := strconv.ParseFloat(f[0], 64)
	m := int(s / 60)
	if m > 0xFFFF {
		m = 0xFFFF
	}
	return m
}
