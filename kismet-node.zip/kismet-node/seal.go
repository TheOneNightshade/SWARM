package main

// Sealed link (protocol.h "Sealed link"; LinkSeal in the app's Broadcast.kt). Keep them in sync.
//
// After the phone proves the owner key with e=1 in its hello, the node answers RSP:hello:OK:e=1 and from
// then on every line both ways is ~<base64 of counter u32 LE | ciphertext | tag[8]>:
//   E = HMAC(owner key, "swarm-enc")[0..16)    S = HMAC(E, "seal" | challenge[8] | node address[6])[0..16)
//   keystream = HMAC(S, 'k' | dir | counter | 0) | HMAC(S, 'k' | dir | counter | 1) | ...
//   tag = HMAC(S, 't' | dir | counter | ciphertext)[0..8)
// dir 'N' node -> phone, 'P' phone -> node. Counters start at 1 and only go up; anything else is dropped.

import (
	"crypto/hmac"
	"encoding/base64"
	"encoding/binary"
	"strings"
)

type sealer struct {
	s         []byte
	me, other byte // direction letters: 'N' and 'P' on the node (the tests' phone swaps them)
	sent      uint32
	heard     uint32
}

func newSealer(owner, challenge []byte, mac [6]byte) *sealer {
	e := hmac256(owner, []byte("swarm-enc"))[:16]
	return &sealer{s: hmac256(e, []byte("seal"), challenge, mac[:])[:16], me: 'N', other: 'P'}
}

func (z *sealer) xor(dir byte, c []byte, d []byte) {
	for i, blk := 0, 0; i < len(d); i, blk = i+32, blk+1 {
		ks := hmac256(z.s, []byte{'k', dir}, c, []byte{byte(blk)})
		for j := 0; j < 32 && i+j < len(d); j++ {
			d[i+j] ^= ks[j]
		}
	}
}

func (z *sealer) tag(dir byte, c, ct []byte) []byte {
	return hmac256(z.s, []byte{'t', dir}, c, ct)[:8]
}

// close seals one line from this side (no \n) and returns it with its \n.
func (z *sealer) close(line string) string {
	z.sent++
	c := make([]byte, 4)
	binary.LittleEndian.PutUint32(c, z.sent)
	ct := []byte(line)
	z.xor(z.me, c, ct)
	f := append(append(append([]byte{}, c...), ct...), z.tag(z.me, c, ct)...)
	return "~" + base64.StdEncoding.EncodeToString(f) + "\n"
}

// open returns the text of a sealed line from the other side, or false if it isn't genuine or is a repeat.
func (z *sealer) open(line string) (string, bool) {
	if !strings.HasPrefix(line, "~") {
		return "", false
	}
	f, err := base64.StdEncoding.DecodeString(line[1:])
	if err != nil || len(f) < 12 {
		return "", false
	}
	c := f[:4]
	ct := append([]byte{}, f[4:len(f)-8]...)
	if !hmac.Equal(z.tag(z.other, c, ct), f[len(f)-8:]) {
		return "", false
	}
	n := binary.LittleEndian.Uint32(c)
	if n <= z.heard {
		return "", false
	}
	z.heard = n
	z.xor(z.other, c, ct)
	return string(ct), true
}
