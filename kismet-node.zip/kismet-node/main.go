// swarm-kismet-node: makes a Linux box or Raspberry Pi running Kismet into a Swarm node. It links to the
// Swarm app over Bluetooth like a node board does, takes Kismet's sightings, and sends them to the phone
// while a scan runs. Kismet decides what is scanned; the app only numbers the node and starts/stops it.
// With the phone away it keeps the sightings on disk until the phone is back.
package main

import (
	"context"
	"flag"
	"fmt"
	"log"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"
)

// Build goes up by one with every change (the app shows it as PROGRAM BUILD on the node's row).
const Build = 2

func logf(format string, a ...any) { log.Printf(format, a...) }

func main() {
	var (
		dir     = flag.String("dir", "/var/lib/swarm-kismet-node", "where the queue and settings are kept")
		kismet  = flag.String("kismet", "http://localhost:2501", "Kismet's web address (empty: don't ask Kismet, use -stdin)")
		user    = flag.String("user", "", "Kismet login name")
		pass    = flag.String("pass", "", "Kismet password")
		apikey  = flag.String("apikey", "", "Kismet API key (instead of -user/-pass)")
		stdin   = flag.Bool("stdin", false, "also read sightings piped in (WiGLE CSV rows or JSON lines)")
		poll    = flag.Duration("poll", time.Second, "how often to ask Kismet for new sightings")
		resend  = flag.Duration("resend", 5*time.Minute, "send a device Kismet still sees again after this long")
		maxQ    = flag.Int("max", 1_000_000, "most sightings held for the phone (oldest go first)")
		hci     = flag.String("hci", "", "Bluetooth adapter to use, e.g. hci1 (default: the first one)")
		every   = flag.Duration("notify", 8*time.Millisecond, "time between Bluetooth notifications")
		forget  = flag.Bool("forget-owner", false, "free this node from its phone's owner lock, then exit")
		showOwn = flag.Bool("owner", false, "show whose node this is, then exit")
		version = flag.Bool("version", false, "print the build and exit")
	)
	flag.Usage = func() {
		fmt.Fprintf(os.Stderr, "swarm-kismet-node build %d: a Swarm node fed by Kismet\n\nUsage: swarm-kismet-node [options]\n\n", Build)
		flag.PrintDefaults()
	}
	flag.Parse()
	log.SetFlags(log.LstdFlags)
	if *version {
		fmt.Printf("swarm-kismet-node build %d\n", Build)
		return
	}
	if err := os.MkdirAll(*dir, 0700); err != nil {
		log.Fatalf("can't make %s: %v", *dir, err)
	}
	node, err := newNode(*dir, *maxQ, *resend)
	if err != nil {
		log.Fatalf("can't open the queue in %s: %v", *dir, err)
	}
	if *forget {
		if err := node.ForgetOwner(); err != nil {
			log.Fatalf("%v", err)
		}
		node.Close()
		fmt.Println("owner forgotten: the next Swarm app to link takes this node")
		return
	}
	if *showOwn {
		fmt.Println(node.OwnerText())
		node.Close()
		return
	}
	logf("swarm-kismet-node build %d, %s, %d sightings waiting from before", Build, node.OwnerText(), node.q.Len())

	ctx, cancel := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer cancel()

	bt, err := newBlueZ(*hci, node, *every)
	if err != nil {
		log.Fatalf("Bluetooth: %v", err)
	}
	if err := bt.Start(); err != nil {
		log.Fatalf("Bluetooth: %v", err)
	}
	go bt.Run(ctx)

	if strings.TrimSpace(*kismet) != "" {
		k := &KismetFeed{base: strings.TrimRight(*kismet, "/"), user: *user, pass: *pass, apikey: *apikey, poll: *poll}
		logf("reading Kismet at %s", k.base)
		go k.Run(ctx, node)
	}
	if *stdin {
		logf("reading sightings from standard input")
		go (&PipeFeed{in: os.Stdin}).Run(ctx, node)
	}

	tick := time.NewTicker(20 * time.Millisecond)
	defer tick.Stop()
	report := time.NewTicker(time.Minute)
	defer report.Stop()
	for {
		select {
		case <-ctx.Done():
			logf("stopping; %d sightings kept for the phone", node.q.Len())
			node.Close()
			time.Sleep(200 * time.Millisecond) // bt.Run unregisters
			return
		case now := <-tick.C:
			node.Tick(now)
		case <-report.C:
			logf("%s", node.Report())
		}
	}
}
