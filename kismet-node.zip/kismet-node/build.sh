#!/bin/sh
# Builds swarm-kismet-node for 64-bit PCs, 64-bit Pi OS and 32-bit Pi OS (any Pi). Needs Go 1.21+.
set -e
cd "$(dirname "$0")"
go test ./...
mkdir -p bin
CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -trimpath -ldflags "-s -w" -o bin/swarm-kismet-node-x86_64 .
CGO_ENABLED=0 GOOS=linux GOARCH=arm64 go build -trimpath -ldflags "-s -w" -o bin/swarm-kismet-node-arm64 .
CGO_ENABLED=0 GOOS=linux GOARCH=arm GOARM=6 go build -trimpath -ldflags "-s -w" -o bin/swarm-kismet-node-armhf .
ls -l bin
